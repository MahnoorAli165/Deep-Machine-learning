import json
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt

from data_prep import DataPrep

# Manually define plot order (use the "model" names from the json files)
ORDER = ['fcn_small', 'fcn_large', 'rnn_small', 'rnn_large', 'lstm_small', 'lstm_large']

folder = Path('results')
loaded = {}
for path in sorted(folder.glob('*.json')):
    with open(path, 'r') as f:
        d = json.load(f)
    loaded[d.get('model', path.stem)] = d

missing = [m for m in ORDER if m not in loaded]
if missing:
    raise KeyError(f'Models in ORDER but not in results/: {missing}. Available: {list(loaded)}')

data = {m: loaded[m] for m in ORDER}

# label, axis title, scale factor applied to the raw value
metrics = {
    'accuracy':         ('Accuracy [%]', 100),
    'training_time_s':  ('Training time [minutes]', 1/60),
    'inference_time_s': ('Inference time [seconds]', 1),
    'param_count':      ('Parameter count', 1)
}

FIGSIZE = (5.5,4)
TICK_ROTATION = 30
TICK_SIZE = 14

def plot(values, filename):
    names = list(values.keys())
    vals = list(values.values())

    fig, ax = plt.subplots(figsize=FIGSIZE)
    bars = ax.bar(names, vals, color='tab:blue')
    ax.bar_label(bars, fmt='%.4g', padding=2)
    ax.margins(y=0.15)
    ax.tick_params(axis='x', labelsize=TICK_SIZE)
    plt.setp(ax.get_xticklabels(), rotation=TICK_ROTATION, ha='right', rotation_mode='anchor')
    fig.tight_layout()

    fig.savefig(filename, dpi=200)
    return fig


def plot_size(data, filename):
    models = list(data.keys())
    param_mb = [data[m]['param_bytes'] / 1e6 for m in models]
    file_mb = [data[m]['file_bytes'] / 1e6 for m in models]
    tick_labels = [m for m in models]

    x = np.arange(len(models))
    width = 0.38

    fig, ax = plt.subplots(figsize=FIGSIZE)
    b1 = ax.bar(x - width / 2, param_mb, width, label='Memory', color='tab:blue')
    b2 = ax.bar(x + width / 2, file_mb, width, label='Disk', color='tab:orange')
    ax.bar_label(b1, fmt='%.4g', padding=2, rotation=TICK_ROTATION)
    ax.bar_label(b2, fmt='%.4g', padding=2, rotation=TICK_ROTATION)

    ax.set_xticks(x)
    ax.tick_params(axis='x', labelsize=TICK_SIZE)
    ax.set_xticklabels(tick_labels, rotation=TICK_ROTATION, ha='right', rotation_mode='anchor')
    ax.legend(loc='upper left')
    ax.margins(y=0.2)
    fig.tight_layout()

    fig.savefig(filename, dpi=200)
    return fig

plot_folder = Path('plots')
plot_folder.mkdir(exist_ok=True)

DataPrep('IMDB Dataset.csv').length_histogram(plot_folder / 'length_histogram.png')

for key, (_, scale) in metrics.items():
    plot_data = {model: d[key] * scale for model, d in data.items()}
    plot(plot_data, plot_folder / f'{key}.png')

plot_size(data, plot_folder / 'size.png')

print(f'RNN training small: {data['rnn_small']['training_time_s']/data['fcn_small']['training_time_s']:.1f}')
print(f'LSTM training small: {data['lstm_small']['training_time_s']/data['fcn_small']['training_time_s']:.1f}')

print(f'RNN training large: {data['rnn_large']['training_time_s']/data['fcn_large']['training_time_s']:.1f}')
print(f'LSTM training large: {data['lstm_large']['training_time_s']/data['fcn_large']['training_time_s']:.1f}')

print(f'RNN inference small: {data['rnn_small']['inference_time_s']/data['fcn_small']['inference_time_s']:.1f}')
print(f'LSTM inference small: {data['lstm_small']['inference_time_s']/data['fcn_small']['inference_time_s']:.1f}')

print(f'RNN inference large: {data['rnn_large']['inference_time_s']/data['fcn_large']['inference_time_s']:.1f}')
print(f'LSTM inference large: {data['lstm_large']['inference_time_s']/data['fcn_large']['inference_time_s']:.1f}')

# plt.show()