import torch
import torch.nn as nn
import torch.nn.functional as F

from constants import VOCAB_SIZE, DEVICE

def load_model(obj, path):
    model = obj()
    state_dict = torch.load(path)
    model.load_state_dict(state_dict)
    model.eval()
    model.to(DEVICE)
    return model


class FCN_Small(nn.Module):
    def __init__(self, seed=42, num_epochs=10, hidden_dim=32):
        super().__init__()
        torch.manual_seed(seed)
        self.num_epochs = num_epochs

        self.net = nn.Sequential(
            nn.Linear(VOCAB_SIZE, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 2),
        )

    def forward(self, x):
        counts = torch.zeros(x.shape[0], VOCAB_SIZE, device=x.device)   # init memory
        counts.scatter_add_(1, x, torch.ones_like(x, dtype=torch.float))# count frequencies
        counts[:, 0] = 0                                                # ignore padding tokens
        counts = counts / counts.sum(dim=1, keepdim=True).clamp(min=1)  # normalize
        return self.net(counts)


class RNN_Small(nn.Module):
    def __init__(self, seed=42, num_epochs=10, embed_dim=32, hidden_dim=32):
        super().__init__()
        torch.manual_seed(seed)
        self.num_epochs = num_epochs

        self.embed = nn.Embedding(VOCAB_SIZE, embed_dim, padding_idx=0) # learned weights on word similarity
        self.rnn = nn.RNN(embed_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, 2)

    def forward(self, x):
        x = self.embed(x)                                   # embed input
        _, h_n = self.rnn(x)                                # RNN
        return self.fc(h_n[-1])                             # last state through FC layer


class LSTM_Small(nn.Module):
    def __init__(self, seed=42, num_epochs=10, embed_dim=32, hidden_dim=32):
        super().__init__()
        torch.manual_seed(seed)
        self.num_epochs = num_epochs

        self.embed = nn.Embedding(VOCAB_SIZE, embed_dim, padding_idx=0) # learned weights on word similarity
        self.lstm = nn.LSTM(embed_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, 2)

    def forward(self, x):
        x = self.embed(x)                                   # embed input
        _, (h_n, _) = self.lstm(x)                          # LSTM
        return self.fc(h_n[-1])                             # last state through FC layer


class FCN_Large(nn.Module):
    def __init__(self, seed=42, num_epochs=5, embed_dim=100, hidden_dim=128):
        super().__init__()
        torch.manual_seed(seed)
        self.num_epochs = num_epochs
        
        self.embedding = nn.Embedding(VOCAB_SIZE, embed_dim, padding_idx=0)
        self.fc1 = nn.Linear(embed_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, 2)

    def forward(self, x):
        # x: (batch_size, seq_len)
        emb = self.embedding(x)              # (batch_size, seq_len, embed_dim)
        mask = (x != 0).unsqueeze(-1)        # (batch_size, seq_len, 1)
        emb = emb * mask                     # zero out PAD embeddings

        # sum over sequence and divide by number of non-pad tokens
        lengths = mask.sum(dim=1)            # (batch_size, 1)
        lengths = torch.clamp(lengths, min=1)
        avg_emb = emb.sum(dim=1) / lengths   # (batch_size, embed_dim)

        h = F.relu(self.fc1(avg_emb))
        out = self.fc2(h).squeeze(1)         # (batch_size,)
        return out


class RNN_Large(nn.Module):
    def __init__(self, seed=42, num_epochs=5, embed_dim=100, hidden_dim=512):
        super().__init__()
        torch.manual_seed(seed)
        self.num_epochs = num_epochs
        
        self.embedding = nn.Embedding(VOCAB_SIZE, embed_dim, padding_idx=0)
        self.rnn = nn.RNN(embed_dim, hidden_dim, batch_first=True, dropout = 0.3)
        self.fc = nn.Linear(hidden_dim, 2)

    def forward(self, x):
        # x: (batch_size, seq_len)
        emb = self.embedding(x)  # (batch_size, seq_len, embed_dim)

        # RNN output:
        # out: (batch_size, seq_len, hidden_dim)
        # h_n: (1, batch_size, hidden_dim)
        out, h_n = self.rnn(emb)

        # final hidden state
        h_last = h_n.squeeze(0)  # (batch_size, hidden_dim)

        logits = self.fc(h_last).squeeze(1)
        return logits


class LSTM_Large(nn.Module):
    def __init__(self, seed=42, num_epochs=5, embed_dim=100, hidden_dim=128):
        super().__init__()
        torch.manual_seed(seed)
        self.num_epochs = num_epochs

        self.embedding = nn.Embedding(VOCAB_SIZE, embed_dim, padding_idx=0)

        self.lstm = nn.LSTM(
            input_size=embed_dim,
            hidden_size=hidden_dim,
            num_layers=1,
            batch_first=True,
            bidirectional=False,
            dropout=0.0
        )

        self.fc = nn.Linear(hidden_dim, 2)

    def forward(self, x):
        # x: (batch_size, seq_len)
        emb = self.embedding(x)  # (batch_size, seq_len, embed_dim)

        # out: (batch_size, seq_len, hidden_dim * num_directions)
        # (h_n, c_n): each is (num_layers * num_directions, batch_size, hidden_dim)
        out, (h_n, c_n) = self.lstm(emb)

        # final hidden state from the last layer
        # shape: (batch_size, hidden_dim * num_directions)
        h_last = h_n[-1]

        logits = self.fc(h_last).squeeze(1)
        return logits