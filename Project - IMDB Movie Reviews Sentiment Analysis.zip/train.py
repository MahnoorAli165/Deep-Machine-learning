import time, copy
from pathlib import Path

import matplotlib.pyplot as plt
from tqdm import tqdm

import torch
import torch.nn as nn

from logger import LOGGER, DEBUG
from constants import DEVICE

class Train:
    def __init__(self, model, data, seed=42):
        self.model = model
        self.data = data
        torch.manual_seed(seed)
        g = torch.Generator().manual_seed(seed)
        self.data.loader_train.sampler.generator = g

        self.optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
        self.loss_fn = nn.CrossEntropyLoss()

        self.model.to(DEVICE)


    def _accuracy(self, y_hat: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        y_hat_labels = torch.argmax(y_hat, dim=1)
        correct_count = torch.sum(y_hat_labels == y)
        acc = correct_count/y.shape[0]
        return acc


    def _training_epoch(self):
        # set model to training mode and init vars
        self.model.train()
        running_loss = 0
        running_acc = 0
        n_samples = 0

        # run one training epoch
        for batch_x, batch_y in tqdm(self.data.loader_train, 'training epoch', leave=False):
            batch_x = batch_x.to(DEVICE)
            batch_y = batch_y.to(DEVICE)

            # training on one batch
            self.optimizer.zero_grad() # clear old gradients
            y_hat = self.model(batch_x)
            loss = self.loss_fn(y_hat, batch_y)
            loss.backward()
            self.optimizer.step() # update weights

            # save loss and accuarcy
            bs = batch_x.shape[0]
            running_loss += loss.item() * bs
            running_acc += self._accuracy(y_hat, batch_y).item() * bs
            n_samples += bs

        # average on all batches
        train_loss = running_loss / n_samples
        train_acc  = running_acc  / n_samples

        return train_loss, train_acc

    def test_accuracy(self):
        _, self.acc = self._validation(self.data.loader_test)
        return self.acc

    def _validation(self, loader=None):
        # set model to validation mode and init vars
        self.model.eval()
        val_loss = 0
        val_acc = 0
        n_val_samples = 0

        if loader is None:
            loader = self.data.loader_val

        # validate model for this training epoch
        with torch.no_grad():
            for batch_x, batch_y in tqdm(loader, 'validation epoch', leave=False):
                batch_x = batch_x.to(DEVICE)
                batch_y = batch_y.to(DEVICE)

                # validation on one batch
                y_hat = self.model(batch_x)
                loss = self.loss_fn(y_hat, batch_y)

                # save loss and accuarcy
                bs = batch_x.shape[0]
                val_loss += loss.item() * bs
                val_acc += self._accuracy(y_hat, batch_y).item() * bs
                n_val_samples += bs

        # average on all batches
        val_loss = val_loss / n_val_samples
        val_acc  = val_acc  / n_val_samples

        return val_loss, val_acc


    def training_loop(self):
        LOGGER.debug('started training loop...')
        start_time = time.time()

        # init vars
        self.plotting_data = {
            'train_loss': [],
            'train_acc': [],
            'val_loss': [],
            'val_acc': []
        }
        train_time = 0
        best_val_loss = float('inf')
        best_state = None
        self.best_epoch = None

        # progress bar if not debug, else print loss and acc each epoch
        iterator = range(self.model.num_epochs)
        if not DEBUG:
            iterator = tqdm(iterator, 'training')

        for epoch in iterator:
            start_epoch = time.time()

            # training
            start_train = time.perf_counter()
            train_loss, train_acc = self._training_epoch()
            self.plotting_data['train_loss'].append(train_loss)
            self.plotting_data['train_acc'].append(train_acc)
            train_time += time.perf_counter() - start_train

            # validation
            val_loss,   val_acc   = self._validation()
            self.plotting_data['val_loss'].append(val_loss)
            self.plotting_data['val_acc'].append(val_acc)

            # keep the best weights so far
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_state = copy.deepcopy(self.model.state_dict())
                self.best_epoch = epoch + 1

            # print loss, acc and time each epoch
            LOGGER.debug(f"Epoch {epoch+1:{len(str(self.model.num_epochs))}}/{self.model.num_epochs} | "
                    f"train_loss={train_loss:.4f} train_acc={train_acc:.4f} | "
                    f"val_loss={val_loss:.4f} val_acc={val_acc:.4f} | "
                    f"completed in {time.time()-start_epoch:.2f} s | "
                    f"training done in {(self.model.num_epochs-epoch-1)*(time.time()-start_epoch):.1f} s")

        self.model.load_state_dict(best_state)
        self.test_accuracy()
        LOGGER.debug(f'Training done in {time.time()-start_time:.2f} s with a test accuracy of {self.acc*100:.1f} % at {self.best_epoch} epochs')

        return train_time


    # plot trends
    def plot(self):
        for label, values in self.plotting_data.items():
            plt.plot(range(1, len(values) + 1), values, label=label)
        plt.xlabel('epoch')
        plt.legend()
        plt.show()


    def save_model(self, path=None):
        if path is None:
            folder = Path('models')
            folder.mkdir(exist_ok=True)
            model_name = self.model.__class__.__name__.lower()
            path = folder / f"{model_name}.pth"

        torch.save(self.model.state_dict(), path)
        LOGGER.debug(f"model saved to {path}")