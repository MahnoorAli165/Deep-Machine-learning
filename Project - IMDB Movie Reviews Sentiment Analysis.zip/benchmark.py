import time, logging, os, json
from pathlib import Path
from datetime import datetime

import torch

from logger import LOGGER
from train import Train
from models import load_model
from constants import DEVICE

class Benchmark:
    def __init__(self, model: callable, data, folder: Path, quick=False):
        self.model_callable = model
        self.data = data
        self.folder = folder
        self.training_runtime = 1 if quick else 60*10 # 10 minutes
        self.inference_runtime = 1 if quick else 60*3 # 3 minutes

        self.model_name = model().__class__.__name__.lower()
        self.model_path = self.folder / f'{self.model_name}.pth'
        self.results_path = self.folder / f'{self.model_name}.json'
        
        self.param_count = None
        self.param_bytes = None
        self.file_bytes = None
        self.accuracy = None
        self.training_time = None
        self.training_count = None
        self.inference_time = None
        self.inference_count = None
        self.benchmark_time = None

        self._run_benchmark()


    def _logger(self, msg, level='debug'):
        LOGGER.log(
            getattr(logging, level.upper()),
            f'{self.model_name} {msg}'
        )

    def _run_benchmark(self):
        start = time.perf_counter()
        self._measure_model_size()
        self._train()
        self._measure_file_size()
        self._inference()

        self.benchmark_time = time.perf_counter() - start
        self._logger(f'total runtime: {self.benchmark_time:.1f} s')
        self._save_results()


    def _measure_model_size(self):
        model = self.model_callable().to(DEVICE)

        self.param_count = sum(p.numel() for p in model.parameters())
        self._logger(f'parameter count: {self.param_count}')

        self.param_bytes = sum(p.numel() * p.element_size() for p in model.parameters())
        self._logger(f'parameter size: {self.param_bytes/1000/1000:.2f} MB')


    def _measure_file_size(self):
        self.file_bytes = os.path.getsize(self.model_path)
        self._logger(f'model file size: {self.file_bytes/1000/1000:.2f} MB')


    def _train(self):
        start_time = time.time()
        end_time = start_time + self.training_runtime # run at least self.training_runtime seconds

        train_times = []
        while time.time() < end_time:
            self._logger(f'round {len(train_times) + 1}, {end_time-time.time():.0f} s left', level='info')
            train = Train(self.model_callable(), self.data)
            train_times.append(train.training_loop())
            

        self.training_time = sum(train_times) / len(train_times)
        self._logger(f'training time: {self.training_time:.2f} s')

        self.training_count = len(train_times)
        self._logger(f'training count: {self.training_count}')

        self.accuracy = train.test_accuracy()
        self._logger(f'accuracy: {self.accuracy*100:.1f} %')

        train.save_model(self.model_path)


    def _inference(self):
        model = load_model(self.model_callable, self.model_path)
        
        with torch.no_grad():
            start_time = time.perf_counter()
            end_time = start_time + self.inference_runtime # run at least self.inference_runtime seconds

            i = 0
            while time.perf_counter() < end_time:
                i += 1
                for batch_x, _ in self.data.loader_test:
                    batch_x = batch_x.to(DEVICE)
                    model(batch_x)

        self.inference_time = (time.perf_counter() - start_time) / i
        self._logger(f'inference time for entire test set: {self.inference_time:.2f} s')

        self.inference_count = i
        self._logger(f'inference count: {self.inference_count}')


    def _save_results(self):
        results = {
            'model': self.model_name,
            'param_count': self.param_count,
            'param_bytes': self.param_bytes,
            'file_bytes': self.file_bytes,
            'accuracy': self.accuracy,
            'training_time_s': self.training_time,
            'training_count': self.training_count,
            'inference_time_s': self.inference_time,
            'inference_count': self.inference_count,
            'benchmark_time': self.benchmark_time,
        }

        with open(self.results_path, 'w') as f:
            json.dump(results, f, indent=2)
        self._logger(f'results saved to {self.results_path}')