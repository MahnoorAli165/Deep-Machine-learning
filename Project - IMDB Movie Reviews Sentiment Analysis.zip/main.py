from pathlib import Path
from datetime import datetime

from logger import LOGGER
from data_prep import DataPrep
from train import Train
from models import *
from benchmark import Benchmark

# models to benchmark
models_emil = [FCN_Small, RNN_Small, LSTM_Small]
models_mahnoor = [FCN_Large, RNN_Large, LSTM_Large]
models = models_emil + models_mahnoor

# create folder to store results
folder = Path('benchmark')
folder.mkdir(exist_ok=True)
folder = folder / datetime.now().strftime(r'%y%m%d_%H%M%S')
folder.mkdir(exist_ok=True)


data = DataPrep('IMDB Dataset.csv')

# warmup
LOGGER.info('warmup')
Train(FCN_Small(), data).training_loop()

# benchmark
for model in models:
    Benchmark(model, data, folder)