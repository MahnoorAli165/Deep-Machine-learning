import time, re
from collections import Counter

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
import torch
from torch.utils.data import Dataset, DataLoader

from logger import LOGGER
from constants import VOCAB_SIZE, MAX_TOKENS

PAD_TOKEN = 0
UNKNOWN_WORD_TOKEN = 1

class DataPrep:
    def __init__(self, path):
        LOGGER.info('started data preperation...')

        self.seed = 42
        self.ratios = (0.8, 0.1, 0.1)
        self.batch_size = 64

        self._load_csv(path)
        self._create_datasets()
        self._create_loaders()

    def _load_csv(self, path):
        start_time = time.time()
        df = pd.read_csv(path, low_memory=False)

        def clean_text(text):
            text = text.lower()                                 # make text lowercase
            text = re.sub(r"<[^>]+>", " ", text)                # strip HTML tags like <br />
            text = re.sub(r"[^a-z0-9' ]+", " ", text)           # keep letters, digits, apostrophes
            text = re.sub(r"(?<![a-z])'|'(?![a-z])", " ", text) # drop apostrophes not between letters
            text = re.sub(r"\s+", " ", text).strip()            # collapse whitespace
            return text

        label_mapping = {'negative': 0, 'positive': 1}

        self.x = df['review'].apply(clean_text).to_numpy()
        self.y = df['sentiment'].map(label_mapping).to_numpy()

        LOGGER.debug(f'loaded .csv and formatted in {time.time()-start_time:.2f} s')


    class _ReviewDataset(Dataset):
        def __init__(self, seqs, labels):
            self.seqs = seqs # list of tensors of varying length
            self.labels = labels

        def __len__(self):
            return len(self.labels)

        def __getitem__(self, i):
            return self.seqs[i], self.labels[i]
        

    def _create_datasets(self):
        start_time = time.time()

        # validate ratios input
        train, val, test = self.ratios
        if abs(sum(self.ratios) - 1) > 1e-9:
            raise ValueError('ratios do not sum to 1')

        idx = np.arange(len(self.y))

        # sklearn function to split dataset, used twice to split into train, val, test
        idx_rest, idx_test = train_test_split(idx, test_size=test, random_state=self.seed)
        new_val = val / (train + val)
        idx_train, idx_val = train_test_split(idx_rest, test_size=new_val, random_state=self.seed)

        # create vocabulary, i.e. the mapping from words to integers
        counts = Counter(w for t in self.x[idx_train] for w in t.split())# tallies how often each word appears
        words = [w for w, _ in counts.most_common(VOCAB_SIZE - 2)]  # only VOCAB_SIZE most common words are kept as a list, -2 for padding and unknonw word tokens
        self.vocab = {w: i + 2 for i, w in enumerate(words)}             # assign ids to each word        

        # encodes and creates dataset mapping review to it's tokenized counterpart
        def make(ids):
            seqs = [
                torch.tensor([self.vocab.get(w, UNKNOWN_WORD_TOKEN) for w in t.split()], dtype=torch.long) # map words to vocab index
                for t in self.x[ids]
            ]
            return self._ReviewDataset(seqs, torch.as_tensor(self.y[ids], dtype=torch.long))

        self.dataset_train = make(idx_train)
        self.dataset_val   = make(idx_val)
        self.dataset_test  = make(idx_test)

        LOGGER.debug(f'datasets created in {time.time()-start_time:.2f} s')

    def _create_loaders(self):
        def collate(batch):
            seqs, labels = zip(*batch)
            longest = max(len(s) for s in seqs)                                 # lenght of longest sequence
            width = longest if MAX_TOKENS is None else min(longest, MAX_TOKENS) # use longest sequence or MAX_TOKENS to define width
            X = torch.full((len(seqs), width), PAD_TOKEN, dtype=torch.long)     # init memory matching the width of longest sequence
            for i, s in enumerate(seqs):
                n = min(len(s), width)                                          # the final width of sequence after possiblöe truncation
                X[i, width - n:] = s[:n]                                        # left pad to match width
            return X, torch.stack(labels)

        self.loader_train = DataLoader(self.dataset_train, self.batch_size, collate_fn=collate, shuffle=True)
        self.loader_val   = DataLoader(self.dataset_val,   self.batch_size, collate_fn=collate, shuffle=False)
        self.loader_test  = DataLoader(self.dataset_test,  self.batch_size, collate_fn=collate, shuffle=False)


    def length_histogram(self, path=None):
        lengths = np.array([len(r.split()) for r in self.x])

        plt.hist(lengths, bins=60)
        plt.axvline(max(lengths), color='red', linestyle='--', label=f'longest review = {max(lengths)} tokens')
        plt.axvline(np.median(lengths), color='black', linestyle=':', label=f'median = {np.median(lengths):.0f}')
        plt.xlabel('review length (tokens)')
        plt.ylabel('number of reviews')
        plt.legend()

        if path is not None:
            plt.savefig(path)
        else:
            plt.show()