import logging

DEBUG = False

LOGGER = logging.getLogger("project")
LOGGER.setLevel(logging.DEBUG if DEBUG else logging.INFO)

handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter(
    "%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S"))
LOGGER.addHandler(handler)
LOGGER.propagate = False   # don't also pass messages to the root logger