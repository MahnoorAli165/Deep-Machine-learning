import torch

VOCAB_SIZE = 20000
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MAX_TOKENS = None